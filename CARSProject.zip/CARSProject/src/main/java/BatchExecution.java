import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class BatchExecution {
	public static void main(String[] args) {
			
	String url = "jdbc:postgresql://localhost:5432/jai";
	String user = "postgres";
	String pass = "root";	
	String query="insert into students values(7,'jai',21)";
	String query1="insert into students values(8,'akash',21)";
	String query2="insert into students values(9,'sureya',20)";
	String query3="insert into students values(10,'jaisureya',21)";
		try( Connection con = DriverManager.getConnection(url, user, pass)) {
			Class.forName("org.postgresql.Driver");
			Statement stmt=con.createStatement();
			stmt.addBatch(query);
			stmt.addBatch(query1);
			stmt.addBatch(query2);
			stmt.addBatch(query3);
			int[] arr=stmt.executeBatch();
			System.out.println(arr);
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}
  }

