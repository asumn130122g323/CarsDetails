import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Arrays;

public class SheelaFood {
   public void insertFoodItem() {
	   String url="jdbc:postgresql://localhost:5432/jai?user=postgres&password=root";
	   try(Connection con=DriverManager.getConnection(url)){
		   String query="insert into Sheela'sfoodshop values(?,?,?,?)";
		   PreparedStatement pstmt=con.prepareStatement(query);
		   pstmt.setInt(1,1);
		   pstmt.setString(2,"dosai");
		   pstmt.setDouble(3,50);
		   pstmt.setString(4,"dosai with sambar combination super");
		   pstmt.addBatch();
		   pstmt.setInt(1,2);
		   pstmt.setString(2,"porota");
		   pstmt.setDouble(3,30);
		   pstmt.setString(4,"porata with curry gravy combination super");
		   pstmt.addBatch();
		   pstmt.setInt(1,3);
		   pstmt.setString(2,"idly");
		   pstmt.setDouble(3,30);
		   pstmt.setString(4,"idly with coconut chutuney combination ultrasuper");
		   pstmt.addBatch();
		   pstmt.setInt(1,4);
		   pstmt.setString(2,"briyani");
		   pstmt.setDouble(3,100);
		   pstmt.setString(4,"briyani with raitha combination ultrasuper");
		   pstmt.addBatch();
		   pstmt.setInt(1,3);
		   pstmt.setString(2,"fried Rice");
		   pstmt.setDouble(3,30);
		   pstmt.setString(4,"fried Rice with tomato ketcup combination ultrasuper");
		   pstmt.addBatch();
		   int[] arr=pstmt.executeBatch();
		   System.out.println(Arrays.toString(arr));
		   
		   
	   }catch(SQLException e) {
		   
	   }
   }
}
