import java.util.Scanner;

public class p1 {
	static Scanner scan=new Scanner(System.in);
public static void otp() throws InterruptedException {
	

	int s=(int)(Math.random()*10000);
	System.out.println("OTP Generating....");
	Thread.sleep(2000);
	System.out.println("Your OTP: "+s);
	System.out.print("Enter Your OTP: ");
	int otp=scan.nextInt();
	if(otp==s) {
		System.out.println("Login Success");
		
	}
	else System.out.println("Incorrect OTP");
}

}
