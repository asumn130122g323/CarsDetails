import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class laststepclose {
	
  public static void main(String[] args)  {
	  Connection con=null;
	  try {
		Class.forName("org.postgresql.Driver");
        String url="jdbc:postgresql://localhost:5432/jai?user=postgres&password=root";
		con=DriverManager.getConnection(url);
		String query="select * from students";
		Statement stmt=con.createStatement();
		ResultSet rs=stmt.executeQuery(query);
		while(rs.next()) {
			System.out.println("car name: "+rs.getString("name"));
		}
//		con.close();
		
	  } catch (ClassNotFoundException | SQLException e) {
	
		e.printStackTrace();
	  }finally {
		  try {
			con.close();
		  } catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		  }
	  }
	  
}

}
