import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class trywithresourceclose {
	
	public static void main(String[] args) {
		
	
	 String url="jdbc:postgresql://localhost:5432/jai?user=postgres&password=root";
	try(Connection con=DriverManager.getConnection(url)) {
		Class.forName("org.postgresql.Driver");
       
		
		String query="select * from students";
		Statement stmt=con.createStatement();
		ResultSet rs=stmt.executeQuery(query);
		while(rs.next()) {
			System.out.println("car name: "+rs.getString("name"));
		}
//		con.close();
		
		
		
	  } catch (ClassNotFoundException | SQLException e) {
	
		e.printStackTrace();
	  }
	
}
}
