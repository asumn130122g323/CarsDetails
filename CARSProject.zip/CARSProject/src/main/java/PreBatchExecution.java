import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.Scanner;

public class PreBatchExecution {
	
   static Scanner sc=new Scanner(System.in);
	public static void main(String[] args) {
		
		String url = "jdbc:postgresql://localhost:5432/jai";
		String user = "postgres";
		String pass = "root";
		try( Connection con = DriverManager.getConnection(url, user, pass)) {
			Class.forName("org.postgresql.Driver");
			boolean start=true;
			String query = "insert into students values(?,?,?)";
			PreparedStatement pstmt = con.prepareStatement(query);
			int[] arr = null;
			while(start) {
				System.out.println("enter 1 to insert data:");
				System.out.println("enter 2 to exit:");				
				System.out.println("enter your choice:");
				int choice=sc.nextInt();
				switch (choice) {
				case 1:					
					System.out.println("enter sid: ");
					int id=sc.nextInt();
					pstmt.setInt(1,id);
					
					sc.nextLine();
					System.out.println("enter sname: ");
					String sname=sc.nextLine();
					pstmt.setString(2,sname);
					
					System.out.println("enter sage: ");
					int sage=sc.nextInt();
					pstmt.setInt(3,sage);
					pstmt.addBatch();
					sc.nextLine();
					
					break;
				case 2:
					arr=pstmt.executeBatch();
					System.out.println(Arrays.toString(arr));
					start=false;
					System.out.println("thankyou");

				default:
					break;
				}
			
			
			}
			
			
			
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
  }

}